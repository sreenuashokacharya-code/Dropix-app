import 'package:flutter/material.dart';

import 'package:firebase_core/firebase_core.dart';

import 'package:supabase_flutter/supabase_flutter.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();

  

  await Firebase.initializeApp(

    options: FirebaseOptions(

      apiKey: 'AIzaSyAklgrWZCTJ38Ze0g7YP69lIBChDQtG68A',

      appId: '1:797732315852:android:394c642711ed77bd091869',

      messagingSenderId: '797732315852',

      projectId: 'sdgram-gds',

      storageBucket: 'sdgram-gds.firebasestorage.app',

    ),

  );

  await Supabase.initialize(

    url: 'https://rfqavxudwmqtsobhlqpq.supabase.co',

    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJmcWF2eHVkd21xdHNvYmhhcXBxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDgxNTgyOTQsImV4cCI6MjA2MzczNDI5NH0.tK4nUFEyH1CZ4kJJnHVWnhANPhly39gytPaaTKVlEW4',

  );

  runApp(DropixApp());

}

class DropixApp extends StatelessWidget {

  @override

  Widget build(BuildContext context) {

    return MaterialApp(

      title: 'Dropix',

      debugShowCheckedModeBanner: false,

      theme: ThemeData.dark().copyWith(

        primaryColor: Colors.blue,

        scaffoldBackgroundColor: Color(0xFF0A0A0A),

      ),

      home: LoginPage(),

    );

  }

}

class LoginPage extends StatefulWidget {

  @override

  State<LoginPage> createState() => _LoginPageState();

}

class _LoginPageState extends State<LoginPage> {

  final email = TextEditingController();

  final password = TextEditingController();

  final supabase = Supabase.instance.client;

  Future<void> login() async {

    try {

      await supabase.auth.signInWithPassword(

        email: email.text,

        password: password.text,

      );

      ScaffoldMessenger.of(context).showSnackBar(

        SnackBar(content: Text('Dropix Login Success 🔥')),

      );

    } catch (e) {

      ScaffoldMessenger.of(context).showSnackBar(

        SnackBar(content: Text('Error: $e')),

      );

    }

  }

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(title: Text('Dropix')),

      body: Padding(

        padding: EdgeInsets.all(20),

        child: Column(

          mainAxisAlignment: MainAxisAlignment.center,

          children: [

            Text('DROPiX', style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold, color: Colors.blue)),

            SizedBox(height: 10),

            Text('Firebase + Supabase Connected', style: TextStyle(color: Colors.green)),

            SizedBox(height: 40),

            TextField(controller: email, decoration: InputDecoration(labelText: 'Email', border: OutlineInputBorder())),

            SizedBox(height: 20),

            TextField(controller: password, decoration: InputDecoration(labelText: 'Password', border: OutlineInputBorder()), obscureText: true),

            SizedBox(height: 30),

            ElevatedButton(

              onPressed: login, 

              style: ElevatedButton.styleFrom(minimumSize: Size(double.infinity, 50)),

              child: Text('Login to Dropix')

            ),

          ],

        ),

      ),

    );

  }

}